package app.carro;

//Carro têm 1 motor (relacionamento de agregação/composição 1 para 1
public class Carro {
	Motor motor; //Implementa o relacionamento 1 para 1
}
