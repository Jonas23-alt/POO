package app.carro;

public class Motor {
	String modelo;
	String cilindradas;
	String anoFabricacao;
	String combustivel;

}
