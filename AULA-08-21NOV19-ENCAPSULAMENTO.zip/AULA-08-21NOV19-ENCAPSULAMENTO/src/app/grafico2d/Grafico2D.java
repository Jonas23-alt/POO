package app.grafico2d;

public class Grafico2D {
	private Ponto2D[] pontos; //Agregação 1 para n
	private int qntPontos; // Quantidade de pontos inseridos  
	
	public Grafico2D(int capacidade) {
		//Instancia o array de Ponto2D com a capaciade passada pelo construtor
		this.pontos = new Ponto2D[capacidade];
		this.qntPontos = 0;
	}
	
	public boolean adicionar(Ponto2D ponto) {
		if(ponto != null && qntPontos < pontos.length) {
			pontos[qntPontos] = ponto;
			qntPontos++;
			
			return true;
		}
		
		return false;
	}
	
	public void listar() {
		for(Ponto2D ponto : pontos) {
			if(ponto != null) {
				System.out.println(ponto.toString());
			} else {
				break;
			}
		}
	}
	
	public Ponto2D buscar(double X, double Y){
		for(Ponto2D ponto: pontos) {
			if(ponto != null) {
			if(ponto != null & ponto.getX() == X && ponto.getY() == Y) {
				return ponto;
			}
		}
		}
		return null;
	}
	public Ponto2D[] getQntPontos() {
		return pontos;
	}


}
