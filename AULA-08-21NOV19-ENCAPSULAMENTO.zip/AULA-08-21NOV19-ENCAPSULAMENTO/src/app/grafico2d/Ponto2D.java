package app.grafico2d;

public class Ponto2D {
	//Declaração dos atributos dos objetos
	double x;
	double y;
	
	//Declaração do construtor
	public Ponto2D(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	//Declaração dos métodos dos objetos
	public void setX(double x) {
		this.x = x;
	}
	
	//alterarY
	public void setY(double y) {
		this.y = y;
	}
	
	//retornarX
	public double getX() {
		return x;
	}
	
	//retornarY
	public double getY() {
		return y;
	}
	
	//retornarPonto "(x,y)"
	public String toString() {
		return "(" + x + "," + y + ")";
	}
	
	
}
