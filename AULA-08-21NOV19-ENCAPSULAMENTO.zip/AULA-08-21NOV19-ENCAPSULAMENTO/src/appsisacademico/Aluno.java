package appsisacademico;

public class Aluno extends Pessoa {
	private int matricula;
	private String turma;
	private String entrada;
	
	
	public int getMatricula() {
		return matricula;
	}
	
	public void setMatricula(int matricula) {
		   this.matricula = matricula;
	}
	public String getTurma() {
		return turma;
	}
	
	public void setTurma (String turma) {
		   this.turma = turma;
	}
	public String getEntrada() {
		return entrada;
	}
	
	public void setEntrada (String entrada) {
		   this.entrada = entrada;
	}
	
	
}

