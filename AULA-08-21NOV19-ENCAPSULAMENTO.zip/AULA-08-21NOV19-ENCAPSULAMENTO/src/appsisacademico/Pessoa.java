package appsisacademico;

public class Pessoa {
		private String nome;
		private String CPF;
		private String RG;
		private String dataNasc;
		
		public String nome() {
		 return nome;

		}
		public void setnome (String nome) {
			 this.nome = nome;

		}
		public String getCPF() {
			return CPF;
		}
		public void setCPF(String cpf) {
		   this.CPF = cpf;
		}
		public String getRG() {
			return RG;
		}
		public void setRG(String rg) {
		   this.RG = rg;
		}
		public String getdataNasc() {
			return dataNasc;
		}
		public void setdataNasc(String dataNasc) {
		   this.dataNasc = dataNasc;
		}
	
	
	
		

	}


