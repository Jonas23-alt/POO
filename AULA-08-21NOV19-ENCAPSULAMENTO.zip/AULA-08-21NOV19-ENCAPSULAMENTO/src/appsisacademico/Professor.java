package appsisacademico;

public class Professor extends Pessoa {

}
