package appsisacademico.test;

import appsisacademico.Pessoa;
import appsisacademico.Professor;
import appsisacademico.Aluno;

public class SistemaAcademicoTest {

	public static void main(String[] args) {
		Pessoa pessoa = new Pessoa();
		
		pessoa.setnome("Josafa");
		pessoa.setCPF("111.111.111-09");
		pessoa.setRG("994354354-6");
		pessoa.setdataNasc("02-08-02");
		

		Aluno aluno = new Aluno();
		
		aluno.setnome("Jesafa");
		aluno.setCPF("111.111.111-09");
		aluno.setRG("994354354-6");
		aluno.setdataNasc("02-08-98");
		
		aluno.setTurma("M�dulo 2 manh�");
		aluno.setEntrada("2019.1");
		
		Tecnico alunoTec = new Tecnico();
		
		alunoTec.setnome("CAEL");
		alunoTec.setCPF("111.111.111-09");
		alunoTec.setRG("994354354-6");
		alunoTec.setdataNasc("02-08-98");
		
		alunoTec.setTurma("M�dulo 2 manh�");
		alunoTec.setEntrada("2019.1");
		alunoTec.setCurso("Inform�tica");
		
		Professor prof = new Professor();
		
		prof.setnome("Walker");
		prof.setCPF("000.000.000-32");
		prof.setRG("000.000.000-32");
		prof.setdataNasc("02-08-92");
		

	}

}
