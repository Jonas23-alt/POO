package test;
import app.grafico2d.Grafico2D;
import app.grafico2d.Ponto2D;

public class Grafico2dTest {

	public static void main(String[] args) {
		Ponto2D ponto1 = new Ponto2D(1, 2);
		Ponto2D ponto2 = new Ponto2D(2, 2);
		Ponto2D ponto3 = new Ponto2D(3, 2);
		Ponto2D ponto4 = new Ponto2D(1, 5);
		Ponto2D ponto5 = new Ponto2D(1, 7);
		
		Grafico2D grafico1 = new Grafico2D(100);

		grafico1.adicionar(ponto1);
		grafico1.adicionar(ponto2);
		grafico1.adicionar(ponto3);
		grafico1.adicionar(ponto4);
		grafico1.adicionar(ponto5);
		
		
		
		grafico1.listar();
		
		Ponto2D resultado = grafico1.buscar(0, 7);
		
		if(resultado != null ) {
		System.out.println("Resultado da busca: " + resultado.toString());
		}
		else {
		System.out.println("o ponto buscado n�o existe!");
		}

	}

}
